//write include required statements


//Write a function(s) prototype  here




