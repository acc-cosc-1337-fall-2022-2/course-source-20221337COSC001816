#include "data_types.h"

//example
int add_numbers(int num1, int num2)
{
	return num1 + num2;
}

//write function code here
int multiply_numbers(int num1)
{
	int num2;
	num2 = 5;
	return num1 * num2;
}



