﻿//example
int add_numbers(int num1, int num2);

//write function prototype here
int multiply_numbers(int num1);



