//Write void function protype named prompt_user with no parameters



//Write void function protype named run_menu with no parameters

