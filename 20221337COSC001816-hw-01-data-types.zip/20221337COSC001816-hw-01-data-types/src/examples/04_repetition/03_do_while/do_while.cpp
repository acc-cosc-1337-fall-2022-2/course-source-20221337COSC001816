#include "do_while.h"

//Write code for void function prompt_user to loop until
//user opts not to continue.  



