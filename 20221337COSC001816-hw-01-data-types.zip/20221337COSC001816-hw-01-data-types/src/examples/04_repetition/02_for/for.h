//Write function prototype for a function named display_numbers 
//that accepts an int and returns void

