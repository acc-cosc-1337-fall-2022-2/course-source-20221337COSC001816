#include"for.h"

int main() 
{
	

	return 0;
}