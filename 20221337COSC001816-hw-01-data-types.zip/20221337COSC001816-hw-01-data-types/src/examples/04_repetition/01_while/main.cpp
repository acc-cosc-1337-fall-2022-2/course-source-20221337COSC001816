#include "while.h"

int main() 
{

	return 0;
}