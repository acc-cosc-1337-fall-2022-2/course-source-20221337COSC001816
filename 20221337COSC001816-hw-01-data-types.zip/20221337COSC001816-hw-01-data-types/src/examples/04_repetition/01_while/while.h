#include<string>

//Write function prototype named sum_of_squares that accepts an int and returns an int.


//write function prototype named display that accepts a string and returns void


