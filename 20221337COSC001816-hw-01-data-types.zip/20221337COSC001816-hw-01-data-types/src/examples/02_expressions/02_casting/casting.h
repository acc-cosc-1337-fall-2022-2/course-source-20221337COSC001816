/*
Write double value-return function convert_to_double with an int years and
double interest_rate parameter
*/


/*
Write int value-return function convert_double_to_int with a double parameter
*/


/*
Write int value-return function static_cast_double_int with a double parameter
*/