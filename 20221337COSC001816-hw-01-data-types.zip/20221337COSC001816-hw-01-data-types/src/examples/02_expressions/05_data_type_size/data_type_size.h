
/*
Write int value-return function int_data_size with int parameter
*/