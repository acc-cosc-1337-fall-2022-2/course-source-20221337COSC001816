
/*
Function int_data_size returns the memory size of an int

@param int num
@return the memory size of an int
*/