/*
Function multi_assign_addition creates three int variables num1, num2, and num3 and
sets their value to incoming parameters, and return the sum of the three variables, 

@param int num
@return the sum of num three times 
*/
