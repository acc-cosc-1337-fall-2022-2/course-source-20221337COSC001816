/*
Write int value-return function multi_assign_addition with int parameter
*/
