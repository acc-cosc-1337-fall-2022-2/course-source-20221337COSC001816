/*
Write value-return function int_overflow with no parameters
*/