/*
Write function prototype operator_precedence_1 with three int parameters
*/

/*
Write function prototype operator_precedence_2 with three int parameters
*/