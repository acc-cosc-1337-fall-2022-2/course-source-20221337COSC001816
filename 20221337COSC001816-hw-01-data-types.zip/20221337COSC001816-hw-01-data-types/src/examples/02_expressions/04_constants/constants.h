/*
Create double value-return function get_area_of_circle with 
double paramter (radius)
*/