//write include statement


//write prototype for function named get_generation that accepts an int and
//returns a string



