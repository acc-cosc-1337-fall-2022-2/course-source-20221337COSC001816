//write include statement for if_else header file

//write code for the is_even function that returns true if num is even, false otherwise