//write function prototype for function named is_even that accepts an int 
//parameter and returns a bool type



