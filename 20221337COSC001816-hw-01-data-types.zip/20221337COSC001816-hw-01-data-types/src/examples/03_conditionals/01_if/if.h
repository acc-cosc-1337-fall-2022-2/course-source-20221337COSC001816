//write function prototype for function named overtime that accepts a double
// and returns a bool type


