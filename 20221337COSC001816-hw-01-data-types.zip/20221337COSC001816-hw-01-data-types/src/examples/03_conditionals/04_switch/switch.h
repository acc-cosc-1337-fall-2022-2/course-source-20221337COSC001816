//write string include
#include<string>

//Write prototype for function that accepts a num and returns a string




