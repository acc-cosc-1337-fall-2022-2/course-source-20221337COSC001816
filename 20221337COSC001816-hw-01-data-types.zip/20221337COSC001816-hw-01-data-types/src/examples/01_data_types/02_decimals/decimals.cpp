//cpp
//header
/*
Write code for function named add_to_double_1 to add .3 3 times to incoming double parameter
*/

/*
Write code for function named add_to_double_1 to add .3 5 times to incoming double parameter
*/
