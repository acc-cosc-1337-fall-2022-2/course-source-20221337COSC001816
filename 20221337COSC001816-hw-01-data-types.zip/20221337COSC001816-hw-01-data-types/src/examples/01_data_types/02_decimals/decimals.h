//header
/*
Write double value-return function named add_to_double_1 that accepts a double parameter
*/


/*
Write double value-return function named add_to_double_2 that accepts a double parameter
*/
