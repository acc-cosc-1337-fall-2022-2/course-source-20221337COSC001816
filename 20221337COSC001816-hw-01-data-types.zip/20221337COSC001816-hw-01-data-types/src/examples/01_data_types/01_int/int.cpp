/*
Function echo_variable returns the incoming parameter

@param int-integer type
@return return the int parameter
*/