//cpp
/*
Function auto_int creates an auto variable with named num with value 10 and returns it.

@param none
@return the num auto variable
*/