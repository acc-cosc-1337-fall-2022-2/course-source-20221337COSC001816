
//create string variable, initialize and display
int main()
{

    return 0;
}