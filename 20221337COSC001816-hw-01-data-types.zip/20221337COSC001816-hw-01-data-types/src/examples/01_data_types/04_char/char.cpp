//cpp


/*
Function get_char_ascii_value with a char parameter

@param char-a character
@return the ASCII value of the character
*/
