//header

/*
Write int function get_char_ascii_value with a char parameter
*/
