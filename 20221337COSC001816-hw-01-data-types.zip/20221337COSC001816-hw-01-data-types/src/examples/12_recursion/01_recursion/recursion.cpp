#include "recursion.h"
#include<iostream>
//Write code for recursive display function


//Write code for recursive factorial
