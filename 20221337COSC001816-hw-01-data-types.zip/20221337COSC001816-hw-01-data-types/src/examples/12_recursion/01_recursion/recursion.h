//Write prototype for void function display with one int parameter

//Write prototype for int value-return function with one int parameter

