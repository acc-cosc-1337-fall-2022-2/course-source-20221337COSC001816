//header iterate_array function with int pointer array and size int for array size
