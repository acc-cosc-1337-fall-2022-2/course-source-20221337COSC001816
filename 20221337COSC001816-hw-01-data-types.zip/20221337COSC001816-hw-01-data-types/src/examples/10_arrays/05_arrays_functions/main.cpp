#include "arr_functions.h"

int main() 
{
	

	return 0;
}