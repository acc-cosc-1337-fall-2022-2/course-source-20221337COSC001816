//
#include<iostream>
#include "arr_functions.h"
//define iterate_array and loop through with ++ increment
