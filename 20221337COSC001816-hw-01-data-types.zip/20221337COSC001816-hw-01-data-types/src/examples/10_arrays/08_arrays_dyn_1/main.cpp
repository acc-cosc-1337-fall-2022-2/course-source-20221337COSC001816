#include<iostream>

int main()
{
	//stack/static array of objects
	
	//read data file or database
	//initialize the balances

	//iterate array with auto and display balance
	
	//stack/static array
	//read data file or database
	//initialize with an initializer list

	//create static array of accounts initalize accounts w 5, 10, 50, and 100 
	

	//write code to display balances

	   
	return 0;
}