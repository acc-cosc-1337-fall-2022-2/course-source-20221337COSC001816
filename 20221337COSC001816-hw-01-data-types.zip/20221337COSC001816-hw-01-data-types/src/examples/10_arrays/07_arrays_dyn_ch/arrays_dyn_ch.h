//dynamic array allocation and deallocation functions
//use getline to end char w \0 auto and show example of manual char termination 