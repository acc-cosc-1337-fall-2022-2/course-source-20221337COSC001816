
//dynamic array allocation and deallocation

int main()
{
	
	return 0;
}