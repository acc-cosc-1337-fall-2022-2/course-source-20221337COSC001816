//arrays_mem.h - stack array example

//function prototype for stack_array