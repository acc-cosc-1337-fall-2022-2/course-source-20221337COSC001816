#include "dynamic_memory.h"
#include<iostream>
//

