//Create allocate and release function

