#include "memory_leak.h"

int main() 
{
	//call function 1 time
	

	//call function in a loop
	
	
	return 0;
}