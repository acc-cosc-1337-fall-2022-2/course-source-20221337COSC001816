//create memory leak function

