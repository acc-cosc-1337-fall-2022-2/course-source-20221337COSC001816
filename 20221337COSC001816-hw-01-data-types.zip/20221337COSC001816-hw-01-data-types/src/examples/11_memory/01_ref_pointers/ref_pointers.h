//Create ref function w reference and pointer parameter 


//Create return pointer function