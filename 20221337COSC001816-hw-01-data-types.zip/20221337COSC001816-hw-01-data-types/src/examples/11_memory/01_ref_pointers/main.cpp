#include "ref_pointers.h"
#include<iostream>

int main() 
{
	
	return 0;
}