//create dangling pointer function
