#include "dangling_pointer.h"

int main() 
{
	

	return 0;
}