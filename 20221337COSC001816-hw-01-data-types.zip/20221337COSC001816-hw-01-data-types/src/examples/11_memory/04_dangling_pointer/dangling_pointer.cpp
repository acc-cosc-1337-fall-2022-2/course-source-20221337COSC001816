#include "dangling_pointer.h"

//
