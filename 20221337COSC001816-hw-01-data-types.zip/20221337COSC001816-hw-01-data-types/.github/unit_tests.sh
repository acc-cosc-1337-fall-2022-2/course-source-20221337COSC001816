cd ../build;
cd test/examples/01_data_types;
./ex_01_tests -s;